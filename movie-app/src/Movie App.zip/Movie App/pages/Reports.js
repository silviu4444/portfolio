import React from 'react'

function Reports() {
    return (
        <div className="reports">
            Reports Page
        </div>
    )
}

export default Reports
