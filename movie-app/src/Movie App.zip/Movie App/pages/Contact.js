import React from 'react'

function Contact() {
    return (
        <div className="contact">
            Contact page
        </div>
    )
}

export default Contact
