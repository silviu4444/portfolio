import React from 'react'

function About() {
    return (
        <div className="about">
            About Page
        </div>
    )
}

export default About
