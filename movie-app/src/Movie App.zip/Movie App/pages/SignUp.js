import React from 'react'

const SignUp = () => {
    return (
        <div className="signUp">Sign Up Page</div>
    )
}
export default SignUp;