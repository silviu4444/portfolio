import About from "./About";
import Contact from "./Contact";
import Home from "./Home";
import Reports from "./Reports";
import SignUp from "./SignUp";

export { About, Contact, Home, Reports, SignUp };
